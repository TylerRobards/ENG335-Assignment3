%% ENG335 Assignment 3 - Genetic Algorithms
% Tyler Robards - 651790
% Baley Eccles - 652137
clc;
app = GeneticAlgorithim;
return