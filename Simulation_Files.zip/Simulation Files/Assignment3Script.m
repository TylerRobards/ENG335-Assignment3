%% ENG335 Assignment 3 - Genetic Algorithms
% Tyler Robards - 651790
% Baley Eccles - 652137

%% INITIAL SETUP
clc; close all; rng(335); % Set a random seed for repeatability
% Setup Matrix (based on assignment spec)
lambdaMatrix = [3, 4, 1, 2, 1, 3, 8;
                 2, 1, 3, 1, 3, 9, 7;
                 5, 1, 2, 4, 4, 9, 8;
                 4, 2, 1, 1, 2, 5, 9;
                 8, 9, 6, 3, 2, 8, 7;
                 9, 8, 5, 2, 1, 7, 9;
                 8, 9, 6, 1, 1, 8, 9];

% GA Parameters
if ~exist('popSize','var'),        popSize = 4; end
if ~exist('numGenerations','var'), numGenerations = 200; end
if ~exist('pCrossover','var'),     pCrossover = 0.9; end
if ~exist('pMutation','var'),      pMutation = 0.15; end
if ~exist('elitismCount','var'),   elitismCount = 2; end
if ~exist('tournamentK','var'),    tournamentK = 3; end
if ~exist('whichPart','var'),      whichPart = 1; end
whichPart=str2double(whichPart);
showProgress   = true;   % live plot of best solution

% Optional: run GA multiple times to check consistency
numRuns = 1;     % set to, e.g., 10 for stats

%% BUILD CITY GRID & HELPERS
% Sector centres: 0.5, 1.5, ..., 6.5 km in both x and y
gridN = 7;
xs = 0.5:1:6.5;  % x-centres (west->east)
ys = 0.5:1:6.5;  % y-centres (south->north)

% Precompute flattened sector list
[XX, YY] = meshgrid(xs, ys);
sectorXY = [XX(:), YY(:)];              % 49x2 list of sector centres
lambdaVec = lambdaMatrix(:);            % 49x1 vector, same order as sectorXY

% River & bridge (Part 2)
riverX   = 5.0;
bridgePt = [5.0, 5.5];

% Fitness function handle
if whichPart == 1
    fitnessFcn = @(ix,iy) fitnessPart1(ix, iy, xs, ys, sectorXY, lambdaVec);
else
    fitnessFcn = @(ix,iy) fitnessPart2(ix, iy, xs, ys, sectorXY, lambdaVec, riverX, bridgePt);
end

%% EXHAUSTIVE CHECK (49 candidates)
% Useful for validating your GA result & writing the report.
[bestEx_ix, bestEx_iy, bestExFitness, exDistance] = exhaustiveSearch( ...
    xs, ys, sectorXY, lambdaVec, whichPart, riverX, bridgePt);

% === EXHAUSTIVE CHECK OUTPUT ===
exMsg = sprintf([ ...
    '\nExhaustive optimum (Part %d):\n' ...
    '  Sector index: ix=%d, iy=%d  (x=%.1f, y=%.1f km)\n' ...
    '  Best fitness = %.6f  (weighted distance = %.6f km)\n' ], ...
    whichPart, bestEx_ix, bestEx_iy, xs(bestEx_ix), ys(bestEx_iy), bestExFitness, 1/bestExFitness);

fprintf('%s', exMsg);   % keep your console print
assignin('base','exMsg',exMsg);   % <-- expose to the app

%% RUN THE GENETIC ALGORITHIM
allBest   = zeros(numRuns, 2);
allFit    = zeros(numRuns, 1);

for r = 1:numRuns
    [bestIx, bestIy, bestFit, histBest] = runGA( ...
        popSize, numGenerations, pCrossover, pMutation, elitismCount, tournamentK, ...
        gridN, fitnessFcn, showProgress, xs, ys, lambdaMatrix, whichPart, riverX, bridgePt);

    allBest(r,:) = [bestIx, bestIy];
    allFit(r)    = bestFit;

   gaMsg = sprintf([ ...
    '\nGA Run %d Result (Part %d):\n' ...
    '  Best ix=%d, iy=%d (x=%.1f, y=%.1f km)\n' ...
    '  Fitness = %.6f  (weighted distance = %.6f km)\n' ], ...
    r, whichPart, bestIx, bestIy, xs(bestIx), ys(bestIy), bestFit, 1/bestFit);

fprintf('%s', gaMsg);
assignin('base','gaMsg',gaMsg);   % <-- expose to the app

    % Compare to exhaustive optimum
    if bestFit < bestExFitness
        warning('GA best is WORSE than exhaustive optimum. Consider tuning GA params.');
    end
end

% Summary if multiple runs
if numRuns > 1
    fprintf('\nSummary over %d GA runs:\n', numRuns);
    fprintf('  Median fitness: %.6f, Max fitness: %.6f\n', median(allFit), max(allFit));
end

%% FINAL PLOT
figure('Name', sprintf('City Map – Part %d', whichPart), 'Color', 'w');
plotCity(lambdaMatrix, xs, ys, whichPart, riverX, bridgePt);
hold on;
% Mark exhaustive optimum
plot(xs(bestEx_ix), ys(bestEx_iy), 'kp', 'MarkerSize', 16, 'MarkerFaceColor', 'y', 'DisplayName', 'Exhaustive Optimum');

% Mark last GA best
plot(xs(allBest(end,1)), ys(allBest(end,2)), 'ro', 'MarkerSize', 10, 'LineWidth', 1.5, 'DisplayName', 'GA Best (last run)');

legend('Location', 'northoutside', 'Orientation', 'horizontal');
title(sprintf('ERU placement (Part %d): GA vs Exhaustive', whichPart));
axis equal tight; grid on;
hold off;

%% LOCAL FUNCTIONS

function [bestIx, bestIy, bestFit, histBest] = runGA( ...
    popSize, numGenerations, pCrossover, pMutation, elitismCount, tournamentK, ...
    gridN, fitnessFcn, showProgress, xs, ys, lambdaMatrix, whichPart, riverX, bridgePt)

    % Population: N x 2 integer matrix, each row = [ix, iy]
    pop = [randi(gridN, popSize, 1), randi(gridN, popSize, 1)];

    % Evaluate initial fitness
    fit = arrayfun(@(k) fitnessFcn(pop(k,1), pop(k,2)), 1:popSize)';

    histBest = zeros(numGenerations,1);

    if showProgress
        fh = figure('Name','GA Progress','Color','w'); 
        plotCity(lambdaMatrix, xs, ys, whichPart, riverX, bridgePt); hold on;
    end

    for gen = 1:numGenerations
        % Elitism: keep top elites
        [fitSorted, idx] = sort(fit, 'descend');
        elites = pop(idx(1:elitismCount), :);

        % New population buffer
        newPop = zeros(popSize, 2);
        newCount = 0;

        % Keep elites
        newPop(1:elitismCount, :) = elites;
        newCount = elitismCount;

        % Fill remainder
        while newCount < popSize
            % Selection via tournament
            p1 = tournamentSelect(pop, fit, tournamentK);
            p2 = tournamentSelect(pop, fit, tournamentK);

            child1 = p1; child2 = p2;

            % Crossover (uniform gene-wise)
            if rand < pCrossover
                [child1, child2] = uniformCrossover(p1, p2);
            end

            % Mutation (per individual)
            if rand < pMutation, child1 = mutate(child1, gridN); end
            if rand < pMutation, child2 = mutate(child2, gridN); end

            % Insert
            newCount = newCount + 1; newPop(newCount,:) = child1;
            if newCount < popSize
                newCount = newCount + 1; newPop(newCount,:) = child2;
            end
        end

        % Replace
        pop = newPop;

        % Evaluate
        fit = arrayfun(@(k) fitnessFcn(pop(k,1), pop(k,2)), 1:popSize)';

        % Track & show progress
        [bestFit, bestIdx] = max(fit);
        histBest(gen) = bestFit;

        if showProgress && isvalid(fh)
            % refresh plot with current best
            cla; plotCity(lambdaMatrix, xs, ys, whichPart, riverX, bridgePt); hold on;
            bi = pop(bestIdx,:);
            plot(xs(bi(1)), ys(bi(2)), 'ro', 'MarkerSize', 10, 'LineWidth', 1.5, ...
                'DisplayName', sprintf('Gen %d Best (%.4f)', gen, bestFit));
            title(sprintf('GA Progress – Generation %d | Best fitness %.6f', gen, bestFit));
            drawnow;
        end
    end

    % Return final best
    [bestFit, bestIdx] = max(fit);
    bestIx = pop(bestIdx,1);
    bestIy = pop(bestIdx,2);
end

function sel = tournamentSelect(pop, fit, K)
    % Randomly sample K and return the fittest
    n = size(pop,1);
    idx = randi(n, K, 1);
    [~, bestLocal] = max(fit(idx));
    sel = pop(idx(bestLocal), :);
end

function [c1, c2] = uniformCrossover(p1, p2)
    % Gene-wise 0.5 swap across two genes [ix, iy]
    mask = rand(1,2) < 0.5;
    c1 = p1; c2 = p2;
    c1(mask) = p2(mask);
    c2(mask) = p1(mask);
end

function c = mutate(c, gridN)
    % Randomly re-draw one or both genes with small probability
    % Here: independent chance per gene (0.5) to re-sample in [1..7]
    if rand < 0.5, c(1) = randi(gridN); end
    if rand < 0.5, c(2) = randi(gridN); end
end

function f = fitnessPart1(ix, iy, xs, ys, sectorXY, lambdaVec)
    % ERU location
    x0 = xs(ix); y0 = ys(iy);
    % Euclidean distances to all sectors (vectorized)
    dx = sectorXY(:,1) - x0;
    dy = sectorXY(:,2) - y0;
    d  = sqrt(dx.^2 + dy.^2);
    % Weighted sum
    S = lambdaVec' * d;
    % Fitness = reciprocal (avoid divide-by-zero with eps)
    f = 1 / max(S, eps);
end

function f = fitnessPart2(ix, iy, xs, ys, sectorXY, lambdaVec, riverX, bridgePt)
    % ERU location
    x0 = xs(ix); y0 = ys(iy);

    % Same-side vs opposite-side routing
    leftSide_eru = x0 < riverX;   % strictly west of x=5
    % Vectorized per sector:
    leftSide_sec = sectorXY(:,1) < riverX;

    sameSide = (leftSide_sec == leftSide_eru);

    % Distances
    d  = zeros(size(sectorXY,1),1);

    % Same side: straight-line Euclidean
    dx = sectorXY(sameSide,1) - x0;
    dy = sectorXY(sameSide,2) - y0;
    d(sameSide) = sqrt(dx.^2 + dy.^2);

    % Opposite sides: route via bridge point
    opp = ~sameSide;
    if any(opp)
        % ERU -> bridge
        d1 = hypot(x0 - bridgePt(1), y0 - bridgePt(2));
        % bridge -> sector
        dx2 = sectorXY(opp,1) - bridgePt(1);
        dy2 = sectorXY(opp,2) - bridgePt(2);
        d2 = sqrt(dx2.^2 + dy2.^2);
        d(opp) = d1 + d2;
    end

    S = lambdaVec' * d;
    f = 1 / max(S, eps);
end

function [bestIx, bestIy, bestFitness, bestDistance] = exhaustiveSearch(xs, ys, sectorXY, lambdaVec, whichPart, riverX, bridgePt)
    gridN = numel(xs);
    bestFitness = -inf;
    bestIx = 1; bestIy = 1;

    for ix = 1:gridN
        for iy = 1:gridN
            if whichPart == 1
                f = fitnessPart1(ix, iy, xs, ys, sectorXY, lambdaVec);
            else
                f = fitnessPart2(ix, iy, xs, ys, sectorXY, lambdaVec, riverX, bridgePt);
            end
            if f > bestFitness
                bestFitness = f;
                bestIx = ix; bestIy = iy;
            end
        end
    end
    bestDistance = 1 / bestFitness;
end

function plotCity(lambdaMatrix, xs, ys, whichPart, riverX, bridgePt)
    % Flip matrix vertically so top row = north
    lambdaToPlot = flipud(lambdaMatrix);

    % Draw heatmap
    imagesc(xs, ys, lambdaToPlot);
    axis image; set(gca,'YDir','normal');
    colormap("hot"); colorbar; hold on;
    xlabel('x (km)'); ylabel('y (km)');
    title(sprintf('City emergency rates (\\lambda), Part %d', whichPart));

    % Grid lines
    for x = 0:1:7
        plot([x x], [0 7], 'k:', 'LineWidth', 0.5);
        plot([0 7], [x x], 'k:', 'LineWidth', 0.5);
    end

    % River & bridge
    if whichPart == 2
        plot([riverX riverX], [0 7], 'c-', 'LineWidth', 2, 'DisplayName','River (x=5)');
        plot(bridgePt(1), bridgePt(2), 'bs', 'MarkerSize', 10, ...
            'LineWidth', 1.5, 'MarkerFaceColor','c', ...
            'DisplayName','Bridge (5, 5.5)');
    end

    % Label λ values at centres (so you see the actual matrix numbers)
    [ny, nx] = size(lambdaToPlot);
    for i = 1:ny
        for j = 1:nx
            text(xs(j), ys(i), num2str(lambdaToPlot(i,j)), ...
                'HorizontalAlignment','center', ...
                'VerticalAlignment','middle', ...
                'FontSize',8, 'Color','w', 'FontWeight','bold');
        end
    end
end